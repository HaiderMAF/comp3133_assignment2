import {
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  lib_default,
  resetCaches
} from "./chunk-JXBFTPJE.js";
import "./chunk-J2SOPSV6.js";
import "./chunk-X6JV76XL.js";
export {
  lib_default as default,
  disableExperimentalFragmentVariables,
  disableFragmentWarnings,
  enableExperimentalFragmentVariables,
  gql,
  resetCaches
};
//# sourceMappingURL=graphql-tag.js.map
